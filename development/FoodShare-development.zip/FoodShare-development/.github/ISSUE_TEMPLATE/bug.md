---
name: Bug
about: Create a report to help us improve
title: "[BUG]"
labels: ''
assignees: ''

---

# 🐛 버그 수정

## 📌 버그 설명

- [ ] 

## 📖 재현 방법

- 

## 📅 예상 작업 기간 및 마감일

- 예상 작업 기간: 
- 마감일: 

## 📝 버그 영향

- 

## 🔗 참고 문서

- [](https://)

## 📈 우선 순위

1. 
2. 
3. 

## 🚧 수정해야 할 기술 스택 및 부분

- 
- 
-
