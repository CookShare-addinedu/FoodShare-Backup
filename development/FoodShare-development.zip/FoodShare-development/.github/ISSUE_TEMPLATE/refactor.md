---
name: Refactor
about: Describe this issue template's purpose here.
title: "[REFACTOR]"
labels: ''
assignees: ''

---

# ♻️ 리팩터링

## 📌 리팩터링 목표

- [ ] 

## 📖 변경될 코드 혹은 구조

- 

## 📅 예상 작업 기간 및 마감일

- 예상 작업 기간: 
- 마감일: 

## 📝 이유 및 목적

- 

## 🔗 참고 문서

- [](https://)

## 📈 우선 순위

1. 
2. 
3. 

## 🚧 영향 받는 기술 스택 및 부분

- 
- 
-
