<div align="center">
    <img width="60%" height="50%" src="https://github.com/FoodShare-addinedu/FoodShare/assets/148300331/8346c1f0-7931-40a0-a7f5-07ee8ef1adc7"/>
</div></br>

***
# 🔍 FoodShare 는 어떤 서비스 인가요 ?
* 푸드 쉐어링을 통해 지역 커뮤니티 활성화 
* 사용자들은 음식을 나누고 교환할 수 있는 기능을 제공

# 💯 Team Ladder 
  사람과 사람 사이의 나눔과 소통의 다리를 놓는 네 명의 개발자
* 조장 : <a href="https://github.com/AN-js">`안정선`</a>
* 조원 : <a href="https://github.com/UKC1">`김강민`</a>
* 조원 : <a href="https://github.com/eun-su-jeong">`은수정`</a>
* 조원 : <a href="https://github.com/5hyunsu">`오현수`</a>

# 💬 프로젝트 진행은 어떻게 하였나요?
* 전체적인 과정을 `Github` 내에서 해결하고자 노력했어요.
* 신뢰를 기반으로 최선의 `협업`을 하고자 했어요 
* 매일 10시 30분 🕥 3시 30분 🕞 회의를 통해서 지속적으로 진행과정을 확인하고 문서로 남기기로 했어요  





