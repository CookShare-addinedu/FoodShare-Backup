package com.example.foodshare.dto;

import lombok.Data;

@Data
public class EnrollUser {
        private String username;
        private String password;
}
