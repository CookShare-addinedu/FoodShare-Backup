
function App() {
  return (
    <div className="App">
  <h1>푸드쉐어페이지입니다.</h1>
    </div>
  );
}

export default App;
